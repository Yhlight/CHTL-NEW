# Runtime test mechanism

The files in the various target subdirectories were automatically generated
and exist as a convenience so that we can test individual targets and also
groups of tests using the development environments like Intellij.